  browser.browserAction.onClicked.addListener(function() {
    browser.runtime.openOptionsPage();
  });
  